package com.example.listacompra;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.io.Serializable;

public class MainActivity2 extends AppCompatActivity implements Serializable {

    private Button boton;
    private EditText edNombre;
    private EditText edCantidad;

    private EditText edPrecio;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        edNombre = new EditText( this );
        edCantidad = new EditText( this );
        edPrecio = new EditText( this );
        boton = this.findViewById(R.id.button);

        boton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                guardar();
            }
        });
    }

    private void guardar(){
        final String text = edNombre.getText().toString();
        final int num = Integer.parseInt(edCantidad.getText().toString());
        final double precio = Double.parseDouble( edPrecio.getText().toString());
        Producto nuevo = new Producto(text, num, precio);
        Intent x = new Intent(this, MainActivity.class);
        x.putExtra("llave", (Serializable) nuevo);
        startActivity(x);

    }
}