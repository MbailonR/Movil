package com.example.listacompra;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.*;

import java.io.Serializable;
import java.util.ArrayList;


public class MainActivity extends Activity implements Serializable {
    /**
     * Called when the activity is first created.
     */

    public ArrayAdapter<Producto> itemsAdapter;

    public SharedPreferences prefs;


    public ArrayList<Producto> items;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_main );

        this.items = new ArrayList<Producto>();

        Button btAdd = (Button) this.findViewById( R.id.btAdd );
        ListView lvItems = (ListView) this.findViewById( R.id.lvItems );

        lvItems.setLongClickable( true );



        this.itemsAdapter = new ArrayAdapter<Producto>(
                this.getApplicationContext(),
                android.R.layout.simple_selectable_list_item,
                this.items
        );
        lvItems.setAdapter( this.itemsAdapter );
        lvItems.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int pos, long l) {
                if ( pos >= 0 ) {
                    MainActivity.this.items.remove( pos );
                    MainActivity.this.itemsAdapter.notifyDataSetChanged();
                    MainActivity.this.updateStatus();
                }
                return false;
            }
        });

        btAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MainActivity.this.onAdd();
            }
        });
    }

    private void onAdd() {
        openActivity2();

        Intent i = getIntent();
        Producto dene = (Producto) i.getSerializableExtra("llave");
        MainActivity.this.itemsAdapter.add(dene) ;
        MainActivity.this.updateStatus();

    }

    private void openActivity2(){
        Intent intent = new Intent(this, MainActivity2.class);
        startActivity(intent);
    }

    private void updateStatus() {
        TextView txtNum = (TextView) this.findViewById( R.id.lblNum );
        txtNum.setText( Integer.toString( this.itemsAdapter.getCount() ) );
    }

    public ArrayAdapter<Producto> getItemsAdapter() {
        return itemsAdapter;
    }

    public void setItemsAdapter(ArrayAdapter<Producto> itemsAdapter) {
        this.itemsAdapter = itemsAdapter;
    }

    public SharedPreferences getPrefs() {
        return prefs;
    }

    public void setPrefs(SharedPreferences prefs) {
        this.prefs = prefs;
    }

    public ArrayList<Producto> getItems() {
        return items;
    }

    public void setItems(ArrayList<Producto> items) {
        this.items = items;
    }
}